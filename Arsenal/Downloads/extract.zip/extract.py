#!/usr/bin/env python3
"""
cs_diag_extractor.py  v2.0
===========================
Universal recursive archive extractor — handles ANY nesting of:
  .7z  .zip  .tar.xz  .tar.gz  .tar.bz2  .tar (plain)  .tar.zst (if zstandard installed)

Detection is magic-byte based (NOT extension based) so renamed/extensionless
archives are handled correctly at every recursion level.

Recursion is fully cross-format:
  .7z → .tar.xz → .zip → .tar.gz → .log   ← all handled

Usage:
  python extract.py <bundle>  --list
  python extract.py <bundle>  --all  --save-to ./extracted
  python extract.py <bundle>  "*.log" "*.txt"
  python extract.py <bundle>  --all  --save-to ./out  -v
"""

import io
import sys
import tarfile
import zipfile
import fnmatch
import logging
import argparse
from pathlib import Path
from typing import Generator, Iterable

try:
    import py7zr
except ImportError:
    raise SystemExit("Missing dependency: pip install py7zr")

# Optional zstd support
try:
    import zstandard as zstd
    HAS_ZSTD = True
except ImportError:
    HAS_ZSTD = False

logger = logging.getLogger(__name__)

DEFAULT_TARGETS = [
    # Known CS diagnostic filenames (with and without extension)
    "opslog*", "perf*", "ring_buffer*", "kernel_filter*",
    "sysinfo*", "cs_sensor*", "falcon*", "diag*", "diagnostic*",
    "exclusion*", "detection*", "alert*", "sensor*", "crowdstrike*",
    # Generic useful extensions
    "*.log", "*.txt", "*.csv", "*.json", "*.xml", "*.out", "*.cfg", "*.conf",
]


# ─────────────────────────────────────────────────────────────────────────────
# ARCHIVE TYPE DETECTION  (magic bytes only — never trust the extension)
# ─────────────────────────────────────────────────────────────────────────────

class ArchiveType:
    UNKNOWN = "unknown"
    SEVENZIP = "7z"
    ZIP      = "zip"
    TAR_XZ   = "tar.xz"
    TAR_GZ   = "tar.gz"
    TAR_BZ2  = "tar.bz2"
    TAR_ZST  = "tar.zst"
    TAR_PLAIN= "tar"      # uncompressed tar — detected by offset magic


_MAGIC = {
    ArchiveType.SEVENZIP : (0,  b"\x37\x7a\xbc\xaf\x27\x1c"),
    ArchiveType.ZIP      : (0,  b"\x50\x4b\x03\x04"),
    ArchiveType.TAR_XZ   : (0,  b"\xfd\x37\x7a\x58\x5a\x00"),
    ArchiveType.TAR_GZ   : (0,  b"\x1f\x8b"),
    ArchiveType.TAR_BZ2  : (0,  b"\x42\x5a\x68"),
    ArchiveType.TAR_ZST  : (0,  b"\x28\xb5\x2f\xfd"),
}

# Plain tar: "ustar" appears at byte offset 257
_TAR_USTAR_OFFSET = 257
_TAR_USTAR_MAGIC  = b"ustar"


def detect(data: bytes) -> str:
    """Return archive type string or ArchiveType.UNKNOWN."""
    for atype, (offset, magic) in _MAGIC.items():
        if atype == ArchiveType.TAR_ZST and not HAS_ZSTD:
            continue
        if len(data) >= offset + len(magic) and data[offset:offset+len(magic)] == magic:
            return atype
    # Plain tar check
    if len(data) > _TAR_USTAR_OFFSET + 5:
        if data[_TAR_USTAR_OFFSET:_TAR_USTAR_OFFSET+5] == _TAR_USTAR_MAGIC:
            return ArchiveType.TAR_PLAIN
    return ArchiveType.UNKNOWN


def is_archive(data: bytes) -> bool:
    return detect(data) != ArchiveType.UNKNOWN


def tar_open_mode(atype: str) -> str:
    return {
        ArchiveType.TAR_XZ   : "r:xz",
        ArchiveType.TAR_GZ   : "r:gz",
        ArchiveType.TAR_BZ2  : "r:bz2",
        ArchiveType.TAR_PLAIN: "r:",
    }.get(atype, "r:*")


def _matches_any(filename: str, patterns: Iterable[str], match_all: bool) -> bool:
    if match_all:
        return True
    name = Path(filename).name
    return any(fnmatch.fnmatch(name.lower(), p.lower()) for p in patterns)


# ─────────────────────────────────────────────────────────────────────────────
# CORE RECURSIVE ENGINE
# Single dispatcher — routes any bytes to the right handler
# ─────────────────────────────────────────────────────────────────────────────

def _recurse(
    data: bytes,
    atype: str,
    targets: list,
    depth: int,
    max_depth: int,
    path: str,
    match_all: bool,
    _list_mode: bool = False,
) -> Generator[tuple[str, bytes, str], None, None]:
    """
    Central dispatcher. Yields (basename, content_bytes, full_path).
    In list mode yields (full_path, size_str, atype_tag) instead.
    """
    if depth > max_depth:
        logger.warning("Max depth %d reached — stopping at: %s", max_depth, path)
        return

    if atype in (ArchiveType.TAR_XZ, ArchiveType.TAR_GZ,
                 ArchiveType.TAR_BZ2, ArchiveType.TAR_PLAIN):
        yield from _handle_tar(data, atype, targets, depth, max_depth, path, match_all, _list_mode)

    elif atype == ArchiveType.TAR_ZST and HAS_ZSTD:
        # Decompress zstd first, then treat as plain tar
        dctx = zstd.ZstdDecompressor()
        decompressed = dctx.decompress(data, max_output_size=500 * 1024 * 1024)
        yield from _handle_tar(decompressed, ArchiveType.TAR_PLAIN,
                               targets, depth, max_depth, path, match_all, _list_mode)

    elif atype == ArchiveType.ZIP:
        yield from _handle_zip(data, targets, depth, max_depth, path, match_all, _list_mode)

    elif atype == ArchiveType.SEVENZIP:
        yield from _handle_7z(data, targets, depth, max_depth, path, match_all, _list_mode)


def _process_entry(
    name: str,
    inner_bytes: bytes,
    targets: list,
    depth: int,
    max_depth: int,
    inner_path: str,
    match_all: bool,
    _list_mode: bool,
) -> Generator[tuple[str, bytes, str], None, None]:
    """
    Called for every entry found inside any archive.
    Decides: recurse deeper, yield as match, or skip.
    """
    inner_type = detect(inner_bytes)

    if _list_mode:
        # In list mode always yield for printing, then recurse into sub-archives
        tag = f"  [{inner_type}]" if inner_type != ArchiveType.UNKNOWN else ""
        size_str = f"{len(inner_bytes):,}"
        yield (inner_path, size_str, tag)
        if inner_type != ArchiveType.UNKNOWN:
            yield from _recurse(inner_bytes, inner_type, targets, depth + 1,
                                 max_depth, inner_path, match_all, _list_mode)
    else:
        if inner_type != ArchiveType.UNKNOWN:
            # It's an archive — recurse into it regardless of name match
            logger.debug("[d=%d] Archive inside archive: %s (%s)", depth, inner_path, inner_type)
            yield from _recurse(inner_bytes, inner_type, targets, depth + 1,
                                 max_depth, inner_path, match_all, _list_mode)
        elif _matches_any(name, targets, match_all):
            logger.info("  ✓ [d=%d] %s  (%d bytes)", depth, inner_path, len(inner_bytes))
            yield (Path(name).name, inner_bytes, inner_path)
        else:
            logger.debug("[d=%d] Skipped: %s", depth, inner_path)


def _handle_tar(
    data, atype, targets, depth, max_depth, path, match_all, _list_mode
):
    try:
        mode = tar_open_mode(atype)
        with tarfile.open(fileobj=io.BytesIO(data), mode=mode) as tf:
            for member in tf.getmembers():
                if not member.isfile():
                    continue
                fobj = tf.extractfile(member)
                if fobj is None:
                    continue
                try:
                    inner_bytes = fobj.read()
                except Exception as e:
                    logger.warning("Cannot read tar member %s: %s", member.name, e)
                    continue
                inner_path = f"{path}/{member.name}"
                yield from _process_entry(member.name, inner_bytes, targets,
                                          depth, max_depth, inner_path, match_all, _list_mode)
    except Exception as e:
        logger.error("TAR error at %s: %s", path, e)


def _handle_zip(data, targets, depth, max_depth, path, match_all, _list_mode):
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            for entry in zf.infolist():
                if entry.is_dir():
                    continue
                try:
                    inner_bytes = zf.read(entry.filename)
                except Exception as e:
                    logger.warning("Cannot read zip entry %s: %s", entry.filename, e)
                    continue
                inner_path = f"{path}/{entry.filename}"
                yield from _process_entry(entry.filename, inner_bytes, targets,
                                          depth, max_depth, inner_path, match_all, _list_mode)
    except zipfile.BadZipFile as e:
        logger.error("Bad ZIP at %s: %s", path, e)


def _handle_7z(data, targets, depth, max_depth, path, match_all, _list_mode):
    try:
        with py7zr.SevenZipFile(io.BytesIO(data), mode="r") as szf:
            all_files = szf.readall()
            for name, bio in all_files.items():
                try:
                    inner_bytes = bio.read()
                except Exception as e:
                    logger.warning("Cannot read 7z entry %s: %s", name, e)
                    continue
                inner_path = f"{path}/{name}"
                yield from _process_entry(name, inner_bytes, targets,
                                          depth, max_depth, inner_path, match_all, _list_mode)
    except Exception as e:
        logger.error("7z error at %s: %s", path, e)


# ─────────────────────────────────────────────────────────────────────────────
# PUBLIC API
# ─────────────────────────────────────────────────────────────────────────────

def extract_diag_files(
    bundle_path,
    targets: list = DEFAULT_TARGETS,
    max_depth: int = 20,
    match_all: bool = False,
) -> Generator[tuple[str, bytes, str], None, None]:
    """
    Yields: (basename, content_bytes, full_archive_path)

    Args:
        bundle_path : any .7z / .zip / .tar.xz / .tar.gz / .tar.bz2 / .tar
        targets     : fnmatch patterns matched on basename
        max_depth   : recursion limit (default 20 — effectively unlimited for real bundles)
        match_all   : if True, extract every non-archive file regardless of name
    """
    bundle_path = Path(bundle_path)
    if not bundle_path.exists():
        raise FileNotFoundError(f"Not found: {bundle_path}")

    raw  = bundle_path.read_bytes()
    atype = detect(raw)
    if atype == ArchiveType.UNKNOWN:
        raise ValueError(
            f"Unrecognised format for: {bundle_path.name}\n"
            f"First 8 bytes: {raw[:8].hex()}"
        )

    logger.info("Bundle type: %s", atype)
    yield from _recurse(raw, atype, targets, depth=1, max_depth=max_depth,
                        path=str(bundle_path), match_all=match_all, _list_mode=False)


def list_bundle(bundle_path, max_depth: int = 20) -> None:
    """Print full inventory tree of any archive bundle."""
    bundle_path = Path(bundle_path)
    raw   = bundle_path.read_bytes()
    atype = detect(raw)

    print(f"\n{'='*70}")
    print(f"  Bundle : {bundle_path.name}")
    print(f"  Size   : {bundle_path.stat().st_size / 1024 / 1024:.2f} MB")
    print(f"  Format : {atype}")
    print(f"{'='*70}\n")

    if atype == ArchiveType.UNKNOWN:
        print(f"[ERROR] Unrecognised format. First 8 bytes: {raw[:8].hex()}")
        return

    prev_depth = [0]

    for full_path, size_str, tag in _recurse(
        raw, atype, [], depth=1, max_depth=max_depth,
        path=str(bundle_path), match_all=True, _list_mode=True
    ):
        # Calculate depth from path separators relative to bundle
        rel = full_path.replace(str(bundle_path), "").lstrip("/\\")
        depth = rel.count("/") + rel.count("\\")
        pad   = "  " * depth
        name  = Path(full_path).name
        print(f"{pad}├─ {name:<60}  {size_str:>12} bytes{tag}")

    print()


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    ap = argparse.ArgumentParser(
        description="Universal recursive archive extractor for CrowdStrike diagnostic bundles",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Supported formats (auto-detected by magic bytes, not extension):
  .7z  .zip  .tar.xz  .tar.gz  .tar.bz2  .tar  (.tar.zst with: pip install zstandard)

Cross-format nesting fully supported:
  .7z → .tar.xz → .zip → .tar.gz → .log   ← all handled

Examples:
  python extract.py FR-1777SLLI004.7z --list
  python extract.py FR-1777SLLI004.7z --all --save-to .\\extracted
  python extract.py FR-1777SLLI004.7z "*.log" "*.txt" --save-to .\\extracted
  python extract.py bundle.tar.xz --all --save-to .\\out -v
        """
    )
    ap.add_argument("bundle",    help="Archive file (.7z/.zip/.tar.xz/.tar.gz/.tar.bz2/.tar)")
    ap.add_argument("patterns",  nargs="*", default=DEFAULT_TARGETS,
                    help="fnmatch patterns to match (default: CS log/txt/csv names)")
    ap.add_argument("--list",    action="store_true",
                    help="Inventory mode: print full tree without extracting")
    ap.add_argument("--all",     action="store_true",
                    help="Extract every non-archive file (ignore patterns)")
    ap.add_argument("--save-to", metavar="DIR",
                    help="Directory to save extracted files into")
    ap.add_argument("--max-depth", type=int, default=20, metavar="N",
                    help="Max recursion depth (default: 20)")
    ap.add_argument("-v", "--verbose", action="store_true",
                    help="Debug logging — shows every file seen at every depth")
    args = ap.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.WARNING,
        format="  %(levelname)s  %(message)s",
    )

    bundle = Path(args.bundle)
    if not bundle.exists():
        print(f"[ERROR] File not found: {bundle}")
        sys.exit(1)

    # ── List mode ──────────────────────────────────────────────────────────
    if args.list:
        list_bundle(bundle, max_depth=args.max_depth)
        sys.exit(0)

    # ── Extraction mode ────────────────────────────────────────────────────
    save_dir = Path(args.save_to) if args.save_to else None
    if save_dir:
        save_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n{'='*70}")
    print(f"  CrowdStrike Diagnostic Extractor  v2.0")
    print(f"{'='*70}")
    print(f"  Bundle    : {bundle.name}  ({bundle.stat().st_size/1024/1024:.2f} MB)")
    print(f"  Mode      : {'ALL FILES' if args.all else 'Pattern match'}")
    if not args.all:
        print(f"  Patterns  : {args.patterns}")
    if save_dir:
        print(f"  Save to   : {save_dir.resolve()}")
    print(f"  Max depth : {args.max_depth}")
    print(f"{'='*70}\n")

    found      = 0
    name_count: dict = {}   # track duplicate basenames

    try:
        for fname, content, archive_path in extract_diag_files(
            bundle,
            targets   = args.patterns,
            max_depth = args.max_depth,
            match_all = args.all,
        ):
            found += 1

            # ── Preview ──
            try:
                preview = content.decode("utf-8", errors="replace")[:120].replace("\n", " ")
            except Exception:
                preview = "<binary>"

            print(f"  [{found:>3}] {fname:<50}  {len(content)/1024:>8.1f} KB")
            print(f"        Source : ...{archive_path[-80:]}")
            print(f"        Preview: {preview[:100]}")

            # ── Save ──
            if save_dir:
                # Deduplicate filenames
                count = name_count.get(fname, 0) + 1
                name_count[fname] = count
                stem   = Path(fname).stem
                suffix = Path(fname).suffix
                out_file = save_dir / (fname if count == 1 else f"{stem}_{count}{suffix}")
                out_file.write_bytes(content)
                print(f"        Saved  : {out_file.name}")
            print()

    except (FileNotFoundError, ValueError) as e:
        print(f"\n[ERROR] {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n\n[INTERRUPTED]")

    # ── Summary ──
    print(f"{'─'*70}")
    if found == 0:
        print("  ⚠  No files matched.\n")
        print("  Diagnostics:")
        print("    1. Run --list to see what is actually inside the bundle")
        print("    2. Run --all  to extract everything regardless of name")
        print("    3. Run -v     to see every file considered and why it was skipped\n")
    else:
        print(f"  ✓  Extracted  : {found} file(s)")
        if save_dir:
            print(f"  ✓  Saved to   : {save_dir.resolve()}")
    print()
